from flask import Flask, render_template, request, redirect, url_for, session
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.feature_selection import SelectKBest, f_regression
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import StandardScaler
from PIL import Image
import numpy as np
import re
import os
from sklearn.ensemble import  ExtraTreesRegressor
from flask import Flask, flash, request, redirect, url_for, render_template
from werkzeug.utils import secure_filename
import matplotlib.pyplot as plt
import numpy as np
import numpy as np
import os
from sklearn.model_selection import train_test_split
from flask import Flask, render_template, request, redirect, url_for, session
from flask_mysqldb import MySQL
from flask import Flask,render_template,url_for,request
from flask_material import Material
from flask import Flask, render_template, request, redirect, url_for, session
from flask_mysqldb import MySQL
from flask import Flask,render_template,url_for,request
from flask_material import Material
import MySQLdb.cursors
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import GridSearchCV
from sklearn.naive_bayes import GaussianNB
from sklearn import svm
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
from sklearn import tree
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
import plotly
import plotly.graph_objs as go
import json
from sklearn.naive_bayes import GaussianNB
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import re
from flask_mysqldb import MySQL
from flask import Flask,render_template,url_for,request
import MySQLdb.cursors
from tensorflow.keras.models import load_model

import joblib


app = Flask(__name__)

# Enter your database connection details below
# app.config['MYSQL_HOST'] = 'localhost'
# app.config['MYSQL_USER'] = 'root'
# app.config['MYSQL_PASSWORD'] = 'root'
# app.config['MYSQL_DB'] = 'fuel'
app.secret_key="dont tell any one"


# mysql = MySQL(app)

# Load the trained model
model = load_model('Fuel.h5')

# Extract the weights of the first layer
first_layer_weights = model.layers[0].get_weights()[0]
feature_importance = np.mean(np.abs(first_layer_weights), axis=1)


# Define feature names
feature_names = ['cylinder', 'displacement', 'hp', 'weight', 'acceleration', 'model_year', 'origin']


# Load the scaler
sc = joblib.load('scaler.pkl')
@app.route('/')
def home():
    return render_template('index.html')



@app.route('/about')
def about():
    return render_template('about.html')


@app.route('/Predict')
def Predict():
    return render_template('Prediction.html')


from skimage import feature

@app.route('/login',methods=['GET', 'POST'])
def login():
    msg = ''

    if request.method == 'POST' and 'username' in request.form and 'password' in request.form:

        username = request.form['username']
        password = request.form['password']
        

        # cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        # cursor.execute('SELECT * FROM user WHERE username = %s AND password = %s', (username, password))
        # # Fetch one record and return result
        # account = cursor.fetchone()
        # print("accountttt",account)

        if username=="admin" and password=="admin" :

            # session['loggedin'] = True
            # session['id'] = account['id']
            # session['username'] = account['username']
            # Redirect to home page
            return render_template('home.html')
        else:
            # Account doesnt exist or username/password incorrect
            msg = 'Incorrect username/password!'
    return render_template('Login.html', msg=msg)

# http://localhost:5000/pythinlogin/register - this will be the registration page, we need to use both GET and POST requests
@app.route('/register', methods=['GET', 'POST'])
def register():
    # Output message if something goes wrong...
    print("cllllllllllllllllllllllllll")
    msg = ''
    # Check if "username", "password" and "email" POST requests exist (user submitted form)
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form and 'email' in request.form:
        # Create variables for easy access
        username = request.form['username']
        email = request.form['email']
        phone = request.form['phone']
                # Check if account exists using MySQL
        place = request.form['place']
        password = request.form['password']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM user WHERE username = %s', (username,))
        account = cursor.fetchone()
        # If account exists show error and validation checks
        if account:
            msg = 'Account already exists!'
        elif not re.match(r'[^@]+@[^@]+\.[^@]+', email):
            msg = 'Invalid email address!'
        elif not re.match(r'[A-Za-z0-9]+', username):
            msg = 'Username must contain only characters and numbers!'
        elif not username or not password or not email:
            msg = 'Please fill out the form!'
        else:
            # Account doesnt exists and the form data is valid, now insert new account into accounts table
            cursor.execute('INSERT INTO user VALUES (NULL, %s, %s, %s,%s,%s)', (username, email, phone,place,password))
            mysql.connection.commit()
            msg = 'You have successfully registered!'
    elif request.method == 'POST':
        # Form is empty... (no POST data)
        msg = 'Please fill out the form!'
    # Show registration form with message (if any)
    return render_template('Register.html', msg=msg)


@app.route('/predict',methods=["POST"])
def predict():
	if request.method == 'POST':
		cylinder = request.form['cylinder']
		displacement = request.form['displacement']
		hp = request.form['hp']
		weight = request.form['weight']
		acceleration = request.form['acceleration']
		model_year = request.form['model_year']
		origin =request.form['origin']

		
		
		sample_data = [cylinder,displacement,hp,weight,acceleration,model_year,origin]
		clean_data = [float(i) for i in sample_data]
		ex1 = np.array(clean_data).reshape(1,-1)

        # Standardize the data using the loaded scaler
		ex1_std = sc.transform(ex1)


        # Make prediction
		prediction = model.predict(ex1_std)
		output = prediction[0][0]
		print("output",output)

		feature_importance_dict =dict(zip(feature_names, feature_importance))




					
		return render_template('Prediction.html',res=1,result1=output,feature_importance=feature_importance_dict)



    
if __name__ =='__main__':
	app.run()
